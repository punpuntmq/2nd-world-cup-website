package config

import (
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

// parse cho api token
func parseTokens(s string) []string {
	parts := strings.Split(s, "|")

	tokens := make([]string, 0, len(parts))

	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			tokens = append(tokens, p)
		}
	}

	return tokens
}

type Config struct {
	RootDir         string
	WebDir          string
	FakeDir         string
	BaseURL         string
	Token           []string
	CompetitionCode string
	Season          string
	Port            string
	RefreshInterval time.Duration
	RefreshTimeout  time.Duration
	QuotaLimit      int
	QuotaWindow     time.Duration
	ForceFake       bool
	AllowedOrigins  []string
}

func Load(rootDir string) Config {
	values := readTokenEnv(filepath.Join(rootDir, "token.env"))
	tokens := parseTokens(getValue(values, "FOOTBALL_DATA_TOKEN", ""))
	forceFake := getBool(values, "USE_FAKE_DATA", true)

	cfg := Config{
		RootDir:         rootDir,
		WebDir:          filepath.Join(rootDir, "web"),
		FakeDir:         filepath.Join(rootDir, "fake-data"),
		BaseURL:         getValue(values, "FOOTBALL_API_BASE_URL", ""),
		Token:           tokens,
		CompetitionCode: getValue(values, "FOOTBALL_DATA_COMPETITION", ""),
		Season:          getValue(values, "FOOTBALL_DATA_SEASON", ""),
		Port:            getValue(values, "PORT", "8080"),
		RefreshInterval: time.Duration(getInt(values, "REFRESH_SECONDS", 30)) * time.Second,
		RefreshTimeout:  time.Duration(getInt(values, "REFRESH_TIMEOUT_SECONDS", 30)) * time.Second,
		QuotaLimit:      effectiveQuotaLimit(tokens, forceFake),
		QuotaWindow:     time.Duration(getInt(values, "FOOTBALL_API_QUOTA_WINDOW_SECONDS", 60)) * time.Second,
		ForceFake:       forceFake,
		AllowedOrigins:  parseList(getValue(values, "CORS_ALLOWED_ORIGINS", "*")),
	}
	return cfg
}

func parseList(s string) []string {
	parts := strings.Split(s, ",")
	values := make([]string, 0, len(parts))
	for _, part := range parts {
		value := strings.TrimSpace(part)
		if value != "" {
			values = append(values, value)
		}
	}
	return values
}

func effectiveQuotaLimit(tokens []string, forceFake bool) int {
	if forceFake || len(tokens) == 0 {
		return 1000
	}
	return len(tokens) * 10
}

func readTokenEnv(path string) map[string]string {
	values := make(map[string]string)
	data, err := os.ReadFile(path)
	if err != nil {
		return values
	}

	for _, rawLine := range strings.Split(string(data), "\n") {
		line := strings.TrimSpace(rawLine)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, value, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		value = strings.Trim(strings.TrimSpace(value), `"'`)
		if key != "" {
			values[key] = value
		}
	}
	return values
}

func getValue(values map[string]string, key, fallback string) string {
	if value := strings.TrimSpace(os.Getenv(key)); value != "" {
		return value
	}
	if value := strings.TrimSpace(values[key]); value != "" {
		return value
	}
	return fallback
}

func getInt(values map[string]string, key string, fallback int) int {
	value := getValue(values, key, "")
	if value == "" {
		return fallback
	}
	parsed, err := strconv.Atoi(value)
	if err != nil || parsed <= 0 {
		return fallback
	}
	return parsed
}

func getBool(values map[string]string, key string, fallback bool) bool {
	value := strings.ToLower(getValue(values, key, ""))
	switch value {
	case "1", "true", "yes", "on":
		return true
	case "0", "false", "no", "off":
		return false
	default:
		return fallback
	}
}
